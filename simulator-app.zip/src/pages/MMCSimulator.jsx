import React, { useState } from "react";
import { generateMMC } from "../services/services";
import DataTable from "../components/DataTable";
import GanttChart from "../components/GanttChart";

function MMCSimulator() {
  const [data, setData] = useState([]);
  const [arrivalMean, setArrivalMean] = useState();
  const [serviceMean, setServiceMean] = useState();
  const [servers, setServers] = useState();
  const [M, setM] = useState(1994)
  const [A, setA] = useState(55)
  const [b, setB] = useState(9)
  const [X0, setX0] = useState(10112166)
  const [ganttData, setGanttData] = useState([])

  const handleSubmit = () => {
    const result = generateMMC(arrivalMean, serviceMean, servers, M, A, b, X0)
    setData(result.simData);
    setGanttData(result.ganttChart)
  };

  const columns = [
    {
      header: "Entity #",
      accessorKey: "Entity",
    },
    {
      header: "Cummulative Probability",
      accessorKey: "CP",
    },
    {
      header: "Cummulative Probability Lookup",
      accessorKey: "CPLookup",
    },

    {
      header: "Time Between Arrival",
      accessorKey: "TimeBWArrival",
    },
    {
      header: "Interarrival",
      accessorKey: "InterArrival",
    },
    {
      header: "Arrival",
      accessorKey: "Arrival",
    },
    {
      header: "Service",
      accessorKey: "Service",
    },
    {
      header: "Priority",
      accessorKey: "Priority",
    },
    {
      header: "Start Time",
      accessorKey: "ServiceStartTime",
    },
    {
      header: "End Time",
      accessorKey: "ServiceEndTime",
    },
    {
      header: "TA Time",
      accessorKey: "TA",
    },
    {
      header: "Wait Time",
      accessorKey: "WT",
    },
    {
      header: "Response Time",
      accessorKey: "RT",
    },
  ];
  return (
    <div>
      <h1 className="font-bold text-2xl">M/M/C Queuing Simulator</h1>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSubmit();
        }}
        className="w-full flex flex-col gap-4 my-4"
      >
        <label htmlFor="" className="flex flex-col">
          <span>Interarrival Time Mean:</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            onChange={(e) => setArrivalMean(e.target.value)}
          />
        </label>
        <label htmlFor="" className="flex flex-col">
          <span>Service Time Mean:</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            onChange={(e) => setServiceMean(e.target.value)}
          />
        </label>
        <label htmlFor="" className="flex flex-col">
          <span>Servers:</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            onChange={(e) => setServers(e.target.value)}
          />
        </label>
        <h2 className="text-xl font-semibold">Priority</h2>
        <label htmlFor="" className="flex flex-col">
          <span>M</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            value={M}
            onChange={(e) => setM(e.target.value)}
          />
        </label>

        <label htmlFor="" className="flex flex-col">
          <span>A</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            value={A}
            onChange={(e) => setA(e.target.value)}
          />
        </label>

        <label htmlFor="" className="flex flex-col">
          <span>b</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            value={b}
            onChange={(e) => setB(e.target.value)}
          />
        </label>

        <label htmlFor="" className="flex flex-col">
          <span>X0</span>
          <input
            className="border rounded-md px-2 py-1"
            required
            value={X0}
            onChange={(e) => setX0(e.target.value)}
          />
        </label>
        <button
          className="bg-[#2daab8] text-white py-1 px-2 rounded-md"
          type="submit"
        >
          Calculate
        </button>
      </form>
      <DataTable columns={columns} data={data} />

      <GanttChart ganttData={ganttData} />
    </div>
  );
}

export default MMCSimulator;
