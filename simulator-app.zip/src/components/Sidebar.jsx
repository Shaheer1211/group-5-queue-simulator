import React from "react";
import { NavLink } from "react-router-dom";

function Sidebar() {
//   const [openSimulations, setOpenSimulations] = useState(false);
  return (
    <aside className="w-[230px] bg-white relative z-20">
      <div className="border p-4 rounded-lg h-screen">
        <ul className="font-semibold text-xl my-4">
          <li className="border-b">
            <NavLink
              to={""}
              end
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              My Orders
            </NavLink>
          </li>
          <li className="border-b">
            <NavLink
              to={"wishlist"}
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              Wish List
            </NavLink>
          </li>
          <li className="border-b">
            <NavLink
            to={"loyalty"}
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              Loyalty Points
            </NavLink>
          </li>
          <li className="border-b">
            <NavLink
            to={"profile"}
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              Profile
            </NavLink>
          </li>
          {/* <li className="border-b">
            <NavLink
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              Become a subscriber
            </NavLink>
          </li> */}
          <li className="border-b">
            <NavLink
            to={"subscriptions"}
              className={`p-2 my-1 rounded-md hover:bg-[#2daab8] hover:text-white w-full inline-block`}
              style={({ isActive }) => {
                return {
                  backgroundColor: isActive ? "#2daab8" : "",
                  color: isActive ? "#fff" : "",
                };
              }}
            >
              Subscribtions
            </NavLink>
          </li>
        </ul>
        <button className="my-4 rounded-full border border-[#2daab8] py-2 px-4 text-[#2daab8] hover:bg-[#2daab8] hover:text-white">
          Logout
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;
